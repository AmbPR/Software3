﻿namespace Denuncias
{
}

namespace Denuncias
{
}
namespace Denuncias
{


    public partial class dbDenunciasDataSet
    {
        partial class tblDenunciasDataTable
        {
        }
    }
}

namespace Denuncias.dbDenunciasDataSetTableAdapters {
    
    
    public partial class tblDenunciasTableAdapter {
    }
}
