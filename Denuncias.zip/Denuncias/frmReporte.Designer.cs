﻿namespace Denuncias
{
    partial class frmReporte
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.rvReporte = new Microsoft.Reporting.WinForms.ReportViewer();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.dbDenunciasDataSet = new Denuncias.dbDenunciasDataSet();
            this.tblDenunciasBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblDenunciasTableAdapter = new Denuncias.dbDenunciasDataSetTableAdapters.tblDenunciasTableAdapter();
            this.txtDoc = new System.Windows.Forms.TextBox();
            this.txtTipoDoc = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dbDenunciasDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblDenunciasBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // rvReporte
            // 
            this.rvReporte.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.rvReporte.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.tblDenunciasBindingSource, "TipoDocumento", true));
            reportDataSource1.Name = "DenunciasDataSet";
            reportDataSource1.Value = this.tblDenunciasBindingSource;
            this.rvReporte.LocalReport.DataSources.Add(reportDataSource1);
            this.rvReporte.LocalReport.ReportEmbeddedResource = "Denuncias.Listado Denuncias.rdlc";
            this.rvReporte.Location = new System.Drawing.Point(11, 76);
            this.rvReporte.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rvReporte.Name = "rvReporte";
            this.rvReporte.ServerReport.BearerToken = null;
            this.rvReporte.Size = new System.Drawing.Size(629, 539);
            this.rvReporte.TabIndex = 1;
            // 
            // btnAceptar
            // 
            this.btnAceptar.Location = new System.Drawing.Point(444, 20);
            this.btnAceptar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(81, 32);
            this.btnAceptar.TabIndex = 6;
            this.btnAceptar.Text = "Aceptar";
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // dbDenunciasDataSet
            // 
            this.dbDenunciasDataSet.DataSetName = "dbDenunciasDataSet";
            this.dbDenunciasDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblDenunciasBindingSource
            // 
            this.tblDenunciasBindingSource.DataMember = "tblDenuncias";
            this.tblDenunciasBindingSource.DataSource = this.dbDenunciasDataSet;
            // 
            // tblDenunciasTableAdapter
            // 
            this.tblDenunciasTableAdapter.ClearBeforeFill = true;
            // 
            // txtDoc
            // 
            this.txtDoc.Location = new System.Drawing.Point(247, 32);
            this.txtDoc.Margin = new System.Windows.Forms.Padding(2);
            this.txtDoc.Name = "txtDoc";
            this.txtDoc.Size = new System.Drawing.Size(99, 20);
            this.txtDoc.TabIndex = 8;
            // 
            // txtTipoDoc
            // 
            this.txtTipoDoc.Location = new System.Drawing.Point(132, 32);
            this.txtTipoDoc.Margin = new System.Windows.Forms.Padding(2);
            this.txtTipoDoc.Name = "txtTipoDoc";
            this.txtTipoDoc.Size = new System.Drawing.Size(103, 20);
            this.txtTipoDoc.TabIndex = 7;
            // 
            // frmReporte
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(651, 626);
            this.Controls.Add(this.txtDoc);
            this.Controls.Add(this.txtTipoDoc);
            this.Controls.Add(this.btnAceptar);
            this.Controls.Add(this.rvReporte);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmReporte";
            this.Text = "frmReporte";
            this.Load += new System.EventHandler(this.frmReporte_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dbDenunciasDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblDenunciasBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer rvReporte;
        private System.Windows.Forms.Button btnAceptar;
        private dbDenunciasDataSet dbDenunciasDataSet;
        private System.Windows.Forms.BindingSource tblDenunciasBindingSource;
        private dbDenunciasDataSetTableAdapters.tblDenunciasTableAdapter tblDenunciasTableAdapter;
        private System.Windows.Forms.TextBox txtDoc;
        private System.Windows.Forms.TextBox txtTipoDoc;
    }
}