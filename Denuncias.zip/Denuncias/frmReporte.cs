﻿using Denuncias;
using Denuncias.dbDenunciasDataSetTableAdapters;
using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Denuncias.dbDenunciasDataSet;

namespace Denuncias
{
    public partial class frmReporte : Form
    {
        tblDenunciasTableAdapter adapter = new tblDenunciasTableAdapter();

        public frmReporte()
        {
            InitializeComponent();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            string TipoDoc, Doc;
            TipoDoc = txtTipoDoc.Text;
            Doc = txtDoc.Text;

           tblDenunciasTableAdapter adapter = new tblDenunciasTableAdapter();
           tblDenunciasDataTable tbl = adapter.GetDataByDoc(TipoDoc, Doc);
           ReportDataSource source = new ReportDataSource("DsReporte", (DataTable)tbl);

           rvReporte.LocalReport.DataSources.Clear();
           rvReporte.LocalReport.DataSources.Add(source);
           rvReporte.RefreshReport();

            this.rvReporte.RefreshReport();
        }

        private void frmReporte_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dbDenunciasDataSet.tblDenuncias' table. You can move, or remove it, as needed.
            this.tblDenunciasTableAdapter.Fill(this.dbDenunciasDataSet.tblDenuncias);

            this.rvReporte.RefreshReport();
        }       
    }
}


