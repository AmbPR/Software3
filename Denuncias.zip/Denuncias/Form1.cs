﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Denuncias
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void denunciaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDenuncia Denuncia = new frmDenuncia();
            Denuncia.MdiParent = this;
            Denuncia.Show();

        }

        private void listadoDeDenunciasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReporte Reporte = new frmReporte();
            Reporte.MdiParent = this;
            Reporte.Show();

        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Seguro que desea salir?", "Mensaje de Sistema", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Application.Exit();

        }
    }
}
