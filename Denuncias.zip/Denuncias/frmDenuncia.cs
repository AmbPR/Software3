﻿using Denuncias.dbDenunciasDataSetTableAdapters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Denuncias
{
    public partial class frmDenuncia : Form
    {
        public frmDenuncia()
        {
            InitializeComponent();
        }

        private void Clear ()
        {
            cmbTipoDoc.SelectedIndex = -1;
            txtDoc.Clear();
            txtNombre.Clear();
            txtApellido.Clear();
            txtSexo.Clear();
            txtFechaNacimiento.Clear();
            txtDetalle.Clear();
            txtIngreso.Clear();
        }
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            SqlTransaction sqlTransaction = null;
            tblDenunciasTableAdapter adapter = new tblDenunciasTableAdapter();

            string TipoDoc, Doc, Nombres, Apellidos, Detalle, Ingreso;
            DateTime FechaNacimiento;
            int Sexo;

            TipoDoc = cmbTipoDoc.SelectedItem.ToString();
            Doc = txtDoc.Text;
            Nombres = txtNombre.Text;
            Apellidos = txtApellido.Text;
            Sexo = int.Parse(txtSexo.Text);
            FechaNacimiento = DateTime.Parse(txtFechaNacimiento.Text);
            Detalle = txtDetalle.Text;
            Ingreso = txtIngreso.Text;

            try
            {
                adapter.Connection.Open();
                sqlTransaction = adapter.Connection.BeginTransaction();
                adapter.Transaction = sqlTransaction;

                object Resultado = adapter.ppInsertDenuncia(TipoDoc, Doc, Nombres, Apellidos, Sexo, FechaNacimiento, Detalle, Ingreso);
                //object Resultado = adapter.ppInsertDenuncia("RNC", "2347", "Ana", "Gomez", 2, DateTime.Parse("1/5/1995"), "Me golpearon", "Carla Perez");

               // MessageBox.Show(Resultado.ToString());

                sqlTransaction.Commit();
                frmReporte Reporte = new frmReporte();
                MessageBox.Show(Resultado.ToString());

                //frmReporte.id = int.Parse(Resultado.ToString());
                Reporte.ShowDialog();


            }
            catch (Exception err)
            {
                sqlTransaction.Rollback();
                Console.WriteLine(err.Message);
                throw;
            }

            Clear();

        }
    }
}
